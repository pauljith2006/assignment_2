import React, { useEffect, useState } from "react";
import { Routes, Route, Link, NavLink } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark shadow-sm py-3">
      <div className="container">
        <Link className="navbar-brand fw-bold d-flex align-items-center" to="/">
          <span className="brand-mark">P</span>
          PeopleHub
        </Link>
        <div className="navbar-nav ms-auto flex-row">
          <NavLink to="/" end className={({ isActive }) =>
            "nav-link px-3 " + (isActive ? "active fw-bold" : "")
          }>Home</NavLink>
          <NavLink to="/employee-form" className={({ isActive }) =>
            "nav-link px-3 " + (isActive ? "active fw-bold" : "")
          }>Employee Form</NavLink>
        </div>
      </div>
    </nav>
  );
}

function Dashboard() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let isMounted = true;
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        if (!response.ok) throw new Error("API request failed");
        return response.json();
      })
      .then((data) => {
        if (isMounted) {
          setEmployees(data);
          setLoading(false);
        }
      })
      .catch(() => {
        if (isMounted) {
          setError("We couldn't load the directory. Check your connection and try again.");
          setLoading(false);
        }
      });
    return () => { isMounted = false; };
  }, []);

  return (
    <main className="container py-4 py-md-5">
      <section className="hero-panel rounded-4 p-4 p-md-5 mb-4 shadow-sm">
        <div className="eyebrow mb-3">People operations · Overview</div>
        <div className="row align-items-center g-4">
          <div className="col-lg-8">
            <h1 className="display-5 fw-bold mb-3">A clearer view of your people.</h1>
            <p className="lead mb-4 text-white-50">
              Keep employee information organised in one simple workspace.
            </p>
            <Link to="/employee-form" className="btn btn-primary rounded-pill px-4 py-2">
              + Add employee
            </Link>
          </div>
          <div className="col-lg-4 d-flex flex-wrap gap-2 justify-content-lg-end">
            <span className="stat-chip">◎ Employee directory</span>
            <span className="stat-chip">↗ Quick entry form</span>
          </div>
        </div>
      </section>

      <div className="d-flex flex-wrap align-items-end justify-content-between gap-3 mb-3">
        <div>
          <div className="section-kicker mb-1">Directory</div>
          <h2 className="h3 fw-bold mb-0">Employee list</h2>
        </div>
        <span className="badge rounded-pill text-bg-light border px-3 py-2">
          {loading ? "Loading records" : error ? "Directory unavailable" : `${employees.length} records`}
        </span>
      </div>

      <section className="card surface-card overflow-hidden">
        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead>
              <tr><th className="ps-4">ID</th><th>Employee name</th><th>Email address</th></tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan="3" className="text-center py-5 text-secondary">Loading employee records…</td></tr>}
              {!loading && error && <tr><td colSpan="3" className="text-center text-danger py-5">{error}</td></tr>}
              {!loading && !error && employees.map((employee) => (
                <tr key={employee.id}>
                  <td className="ps-4 text-secondary">{String(employee.id).padStart(2, "0")}</td>
                  <td className="fw-semibold">
                    <span className="employee-avatar">{employee.name.split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase()}</span>
                    {employee.name}
                  </td>
                  <td><a className="link-secondary text-decoration-none" href={`mailto:${employee.email}`}>{employee.email}</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <p className="small text-secondary mt-3 mb-0">Directory sample data is provided by JSONPlaceholder.</p>
    </main>
  );
}

function EmployeeForm() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitted(true);
  }

  return (
    <main className="container py-4 py-md-5">
      <div className="form-card">
        <div className="section-kicker mb-2">People operations · New record</div>
        <div className="card surface-card p-4 p-md-5">
          <h1 className="fw-bold mb-2">Add an employee</h1>
          <p className="text-secondary mb-4">Fill in the details below to complete the employee entry.</p>

          {submitted && <div className="alert alert-success" role="status">
            Employee details submitted successfully.
          </div>}

          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              <div className="col-md-6">
                <label htmlFor="employeeName" className="form-label">Full name</label>
                <input id="employeeName" type="text" className="form-control" placeholder="e.g. Alex Thomas" required />
              </div>
              <div className="col-md-6">
                <label htmlFor="designation" className="form-label">Designation</label>
                <input id="designation" type="text" className="form-control" placeholder="e.g. Project Manager" required />
              </div>
              <div className="col-md-6">
                <label htmlFor="location" className="form-label">Location</label>
                <input id="location" type="text" className="form-control" placeholder="e.g. Kochi" required />
              </div>
              <div className="col-md-6">
                <label htmlFor="salary" className="form-label">Salary</label>
                <input id="salary" type="number" className="form-control" placeholder="Enter salary amount" min="0" required />
              </div>
              <div className="col-12 d-flex flex-wrap gap-2 mt-4">
                <button type="submit" className="btn btn-primary rounded-pill px-4">Submit details</button>
                <Link to="/" className="btn btn-outline-secondary rounded-pill px-4">Back to directory</Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/employee-form" element={<EmployeeForm />} />
      </Routes>
      <footer className="text-center py-4 small">
        PeopleHub · Assignment 2 · Pauljith
      </footer>
    </>
  );
}

export default App;
