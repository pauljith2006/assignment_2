# Assignment 2 — PeopleHub Employee Portal

**Student:** Pauljith

## Features
- Responsive React employee dashboard
- Home and Employee Form navigation with React Router
- Employee directory fetched from the JSONPlaceholder users API
- Employee form with Name, Designation, Location and Salary fields
- Bootstrap layout with a custom emerald-and-sand theme
- Loading and error states for the employee directory

## Requirements
- Node.js and npm

## Run locally
Open a terminal in this folder and run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite in your terminal.

To create a production build, run `npm run build`.
